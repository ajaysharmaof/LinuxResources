#!/usr/bin/bash
x=56
y=78.9
my_name="shell scripting"
x2=67

echo "x=$x"
echo "x2=$x2"
echo "y=$y"
echo "my_name=$my_name"