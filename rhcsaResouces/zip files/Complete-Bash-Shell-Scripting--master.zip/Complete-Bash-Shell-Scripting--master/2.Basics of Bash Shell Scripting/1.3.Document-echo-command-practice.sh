#!/usr/bin/bash
echo "This is a simple messgae"
echo 
echo 
echo -n  "This is one more line"
echo "Today date is: $(date)"
echo "The user name is: $USER"
echo -e "This is a first line.\nThis is a second line"
echo "Welcome to shell scripting"
echo -e "\033[1;31mNow we are good with usage of echo command\033[0m"